//import logo from './logo.svg';
//import './App.css';
import './theme-assest/css/bootstrap.min.css';
import './theme-assest/css/animate.min.css';
import './theme-assest/css/aos.css';
import './theme-assest/css/magnific-popup.css';
import './theme-assest/css/fontawesome-all.min.css';
import './theme-assest/css/owl.carousel.min.css';
import './theme-assest/css/flaticon.css';
import './theme-assest/css/odometer.css';
import './theme-assest/css/slick.css'
import './theme-assest/css/default.css';
import './theme-assest/css/style.css';
import './theme-assest/css/responsive.css'
import TopHeader from './theme-layout/headers/top-header/TopHeader';
import MainHeader from './theme-layout/headers/main-header/MainHeader';
import FooterCopyright from './theme-layout/footers/footer-copyright/FooterCopyright';
import FooterTop from './theme-layout/footers/footer-top/FooterTop';
import Banner from './theme-layout/banner-area/Banner';
import BrandArea from './theme-layout/brand-area/BrandArea';
import Features from './theme-layout/features-area/Features';
import Feedback from './theme-layout/feedback/Feedback';
import Service from './theme-layout/service-area/Service';
import Trail from './theme-layout/trail-area/Trail';
import Support from './theme-layout/support-area/Support';


function App() {
  return (
    <>
      <header>
       <TopHeader/>
       <MainHeader/>
      </header>
      <Banner/>
      <BrandArea/>
      <Features/>
      <Feedback/>
      <Service/>
      <Trail/>
      < Support/>
    <footer>
     
      <FooterTop/>
      <FooterCopyright/>
    </footer>
    </>
  );
}

export default App;
