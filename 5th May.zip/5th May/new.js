// import {salaryDetails} from ".\4th May-Inheritance\inherit.js";
import {employee} from "../4th May-Inheritance/inherit.js";
let a = new employee("Avinash", "Developer", 50000);
a.empInfo();