import React from 'react'

 const Home = () => {
  return (
    <div className='display-1'><b>Routing</b></div>
)
}
export default Home